const { addSubject } = require('../controller/SubjectController')

const router = require('express').Router()

router.post('/addsubject',addSubject)

module.exports = router